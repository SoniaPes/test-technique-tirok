<?php

include 'inc/init.inc.php';
include 'inc/function.inc.php';




include 'inc/header.inc.php';
include 'inc/nav.inc.php';



// CREATION DES VARIABLES POUR LES CHAMPS DU FORMULAIRE D INSCRIPTION
$pseudo = '';
$mdp = '';
$nom = '';
$prenom = '';
$email = '';
$telephone = '';
$civilite = '';

// on vérifie l'existence des éléments dans POST
if( isset($_POST['pseudo']) && isset($_POST['mdp']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['email']) && isset($_POST['telephone']) && isset($_POST['civilite']) ){

// on place chaque informations dans une variable plus simple en écriture et on applique un trim au passage.
    $pseudo = trim($_POST['pseudo']);
    $mdp = trim($_POST['mdp']);
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $email = trim($_POST['email']);
    $telephone = trim($_POST['telephone']);
    $civilite = trim($_POST['civilite']);

    // création de la variable $erreur pour controle des erreur dans tests 
    $erreur = false;

    if(iconv_strlen($pseudo) < 4 || iconv_strlen($pseudo) > 15 ){
        $erreur = true;
        $msg = '<div class="alert alert-danger mb-3">Le pseudo doit contenir entre 4 et 15 caractères !</div>'; 
    }

    $test_caractere = preg_match('#^[a-zA-Z0-9._-]+$#', $pseudo);

    if( $test_caractere == false){
        
        $erreur = true;
        $msg .= '<div class="alert alert-danger mb-3">Attention , les caractères autorisés: a-z 0-9._-</div>';
    }

     // Verification du pseudo dans BDD si disponible
     $test_caractere = $pdo->prepare("SELECT * FROM membre WHERE pseudo = :pseudo");
     $test_caractere->bindParam(':pseudo', $pseudo, PDO::PARAM_STR);
     $test_caractere->execute(); // on execute si pseudo dispo, sinon:
 
     if( $test_caractere->rowCount() > 0 ){
         
         $erreur = true;
         $msg .= '<div class="alert alert-danger mb-3">Le pseudo est indisponible !</div>'; 
 
  
     }

     // CONTROLE DU MAIL SI EMAIL ADRESS VALIDE:
    if( filter_var($email, FILTER_VALIDATE_EMAIL) == false){

        $erreur = true;
        $msg .= '<div class="alert alert-danger mb-3">Le format email est invalide !</div>'; 

    }


    // le MDP NE DOIT PAS ETRE VIDE
    if(empty($mdp)){
        $erreur = true;
        $msg .= '<div class="alert alert-danger mb-3">Le mot de passe est obligatoire !</div>'; 

    }

    if($erreur == false){

        $mdp = password_hash($mdp, PASSWORD_DEFAULT);

        $enregistrement = $pdo->prepare("INSERT INTO membre(pseudo, mdp, nom, prenom, email, telephone, civilite, statut, date_enregistrement)VALUES(:pseudo, :mdp, :nom, :prenom, :email, :telephone, :civilite, 1, NOW())");

        $enregistrement->bindParam(':pseudo', $pseudo, PDO::PARAM_STR);
        $enregistrement->bindParam(':mdp', $mdp, PDO::PARAM_STR);
        $enregistrement->bindParam(':nom', $nom, PDO::PARAM_STR);
        $enregistrement->bindParam(':prenom', $prenom, PDO::PARAM_STR);
        $enregistrement->bindParam(':email', $email, PDO::PARAM_STR);
        $enregistrement->bindParam(':telephone', $telephone, PDO::PARAM_STR);
        $enregistrement->bindParam(':civilite', $civilite, PDO::PARAM_STR);
        $enregistrement->execute();

        $msg .= '<div class="alert alert-succes mb-3">Inscription réussit !</div>';

       // header('location:inscription.php');


    }


}


?>

<!----FORMULAIRE D INSCRIPTION ----->

<main class="container">
   

        <div class="bg-light p-5 mt-5 rounded">
                <h1><i class="text-primary fas fa-user-alt"></i> INSCRIPTION <i class="text-primary fas fa-user-alt"></i></h1>
            </div><?php echo $msg; ?>

            <div class="row">
                <div class="col-6 mx-auto mt-5">
                    <!-- faire un formulaire avec les deux champs suivant : pseudo / mdp + un bouton de validation -->
                    <form method="post" >
                        <div class="mb-2">
                            <label for="pseudo" class="form-label">Pseudo <i class="text-primary fas fa-user-alt"></i></label>
                            <input type="text" class="form-control" id="pseudo" name="pseudo" value="<?php echo $pseudo; ?>">
                        </div>
                        <div class="mb-2">
                            <label for="mdp" class="form-label">Mot de passe </label>
                            <input type="password" class="form-control" id="mdp" name="mdp">
                        </div>
                        <div class="mb-2">
                            <label for="nom" class="form-label">Votre nom </label>
                            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo $nom; ?>">
                        </div>
                        <div class="mb-2">
                            <label for="prenom" class="form-label">Votre prénom</label>
                            <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo $prenom; ?>">
                        </div>
                        <div class="mb-2">
                            <label for="email" class="form-label">Votre email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
                        </div>
                        <div class="mb-2">
                            <label for="telephone" class="form-label">Votre Téléphone</label>
                            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo $telephone; ?>">
                        </div>
                        <div>
                        <select class="form-select" id="civilite" name="civilite">
                                    <option value="m">homme</option>
                                    <option value="f" <?php if($civilite == 'f'){ echo 'selected'; } ?>>femme</option>
                                </select>
                        </div>
                      
                        <div class="mb-2 mt-4 mb-5 ">
                            <button type="submit" class="btn btn-outline-primary w-100" id="connexion">Inscription</button>
                        </div>
                    </form>
                </div>
            </div>
       
        </main>


        <?php

        include 'inc/footer.inc.php';