<?php

include 'inc/init.inc.php';
include 'inc/function.inc.php';

// Restriction d'accès: si l'utilisateur n'est pas connecté, on redirige vers connexion.php

if(user_is_connected() == false){
    header('location: connexion.php');
}







include 'inc/header.inc.php';
include 'inc/nav.inc.php';


?>

<main class="container">
  
    <div class="bg-light p-5 rounded">
        <h1><i class="text-primary fas fa-user-alt"></i> Profile  </h1>
        <p class="lead">Bienvenue sur notre site.
            <hr><?php echo $msg; ?>
        </p>
    </div>

    <div class="row">
        <div class="col-sm-6 mt-5">
            <?php
                // Affichez les informations de l'utilisateur
                // Pour sexe, il faut afficher homme ou femme pas m ou f
                // Pour le statut : on affiche "Vous êtes administrateur" ou "Vous êtes membre"

                if($_SESSION['membre']['civilite'] == 'm') {
                    $civilite = 'homme';
                } else {
                    $civilite = 'femme';
                }

                if($_SESSION['membre']['statut'] == 1) {
                    $statut = 'membre';
                } else {
                    $statut = 'administrateur';
                }
            ?>
            <ul class="list-group">
                <li class="list-group-item bg-indigo text-dark p-3">Bonjour <?php echo ucfirst($_SESSION['membre']['prenom']) . ' ' . ucfirst($_SESSION['membre']['nom']); ?> </li>
                <li class="list-group-item p-3"><b>N° utilisateur: </b><?php echo $_SESSION['membre']['id_membre']; ?></li>
                <li class="list-group-item p-3"><b>Pseudo : </b><?= $_SESSION['membre']['pseudo']; ?></li>
                <!-- la balise au dessus avec le  signe = provoque un affichage. Dans cette balise, le echo est inclu -->                
                <li class="list-group-item p-3"><b>Nom : </b><?php echo $_SESSION['membre']['nom']; ?></li>
                <li class="list-group-item p-3"><b>Prénom : </b><?php echo $_SESSION['membre']['prenom']; ?></li>
                <li class="list-group-item p-3"><b>Email : </b><?php echo $_SESSION['membre']['email']; ?></li>
                <li class="list-group-item p-3"><b>Civilite : </b><?php echo $civilite; ?></li>
                <li class="list-group-item p-3"><b>Statut : </b>vous êtes <?php echo $statut; ?></li>
                
            </ul>

        </div>
        
    </div>
</main>

<?php
include 'inc/footer.inc.php';

