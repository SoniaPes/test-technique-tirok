<?php


include 'inc/init.inc.php';
include 'inc/function.inc.php';







        





include 'inc/header.inc.php';
include 'inc/nav.inc.php';


?>
            
<?php

include 'inc/footer.inc.php';
  
 


    


