<?php

// Fonction pour tester si l'utilisateur est connecté
function user_is_connected() {
    // on vérifie si SESSION n'existe pas ou est vide.
    if(empty($_SESSION['membre'])) {
        return false;
    } else {
        return true;
    }
}

//  si utilisateur est administrateur
function user_is_admin(){
    if( user_is_connected() && $_SESSION['membre']['statut'] == 2){
        return true;
    }else{
        return false;
    }
}

?>
