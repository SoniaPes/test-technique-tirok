<?php

$host = 'mysql:host=localhost;dbname=tirok'; 
$login = 'root'; // login
$password = ''; // mdp
$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, 
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' 
);
$pdo = new PDO($host, $login, $password, $options);

// Création d'une variable vide que l'on appelle sur toutes nos pages en dessous du titre de la page. Cette variable nous permet de mettre des messages utilisateur dedans, ils s'afficheront naturellement ensuite.

$msg = '';

// Création/ouverture de la session
session_start();

// Déclaration de constantes
// url absolue
define('URL', 'http://localhost/tirok/'); // à modifier lors de la mise en ligne
// Chemin racine serveur pour l'enregistrement des fichiers chargés via le formulaire. 
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT']); // cette information est récupérée dans la superglobale $_SERVER: exemple : C:/wamp64/www

// Chemin depuis le serveur vers notre site
define('PROJECT_PATH', '/localhost/tirok/'); // à modifier lors de la mise en ligne / -> offline